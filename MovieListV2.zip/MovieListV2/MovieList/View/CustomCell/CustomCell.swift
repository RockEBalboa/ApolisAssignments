//
//  CustomCell.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/24/21.
//

import UIKit

class CustomCell: UITableViewCell {

//    @IBOutlet weak var ratingLabel: UILabel!
//    @IBOutlet weak var popularityLabel: UILabel!
//    @IBOutlet weak var movieTitle: UILabel!
//    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var popularityLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    
    
    var movie: Movie?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // This function populates the 3 labels and ImageView inside of the customCell class. Image is the movie poster and labels consist of movieTitle, popularity, and rating.
    func populate() {
        movieTitle.text = movie?.title
        popularityLabel.text = "Popularity: \(movie?.popularity ?? -1)"
        ratingLabel.text = "\(movie?.release_date ?? "")"
        
        let imgUrl = (Constant.IMAGE_BASE_URL.rawValue + (movie?.backdrop_path ?? ""))
        imgView.imageFromServerURL(imgUrl)
    }
}
