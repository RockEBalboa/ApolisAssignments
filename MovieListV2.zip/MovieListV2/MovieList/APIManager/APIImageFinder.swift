//
//  APIImageFinder.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/28/21.
//
import UIKit
class APIImageFinder {
    
}
extension  UIImageView {
    //This function grabs an image based on the URL in the parameters
    func imageFromServerURL(_ URLString: String) {
        
        let imagae_url = Constant.IMAGE_BASE_URL.rawValue + URLString
        
        if let url = URL(string: imagae_url) {
            
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                
               
                DispatchQueue.main.async {
                    if let data = data {
                        if let downloadedImage = UIImage(data: data) {
                            
                            self.image = downloadedImage
                        }
                    }
                }
            }).resume()
        }
    }
}
