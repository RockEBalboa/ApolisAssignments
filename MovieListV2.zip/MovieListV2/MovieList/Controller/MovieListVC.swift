//
//  MovieListVC.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/24/21.
//

import UIKit

class MovieListVC: UIViewController, UITableViewDelegate, UITableViewDataSource, APIManagerDelegate, UISearchBarDelegate {

    @IBOutlet weak var movieListTbl: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var movieList : MovieList?
    var filteredMovies : MovieList?
    var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        filteredMovies = MovieList()

        movieListTbl.delegate = self
        let nib = UINib(nibName: "CustomCell", bundle: nil)
        
        movieListTbl.register(nib, forCellReuseIdentifier: "CustomCell2")
        
        let apiMngrObj = ApiManager.shared
        apiMngrObj.delegate = self
        apiMngrObj.getMovieListFromServer(url: Constant.MOVIE_LIST_URL.rawValue)
    }
    
    //sets the number of rows per section for the table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if !isSearching {
            return movieList?.results?.count ?? 0
        } else {
            return filteredMovies?.results?.count ?? 0
        }
    }
    
    // This function builds and sets a CustomCell that will represent a movie in a MovieList
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = movieListTbl.dequeueReusableCell(withIdentifier: "CustomCell") as? CustomCell
        
        if !isSearching {
            cell?.movie = movieList?.results?[indexPath.row]
        } else {
            cell?.movie = filteredMovies?.results?[indexPath.row]
        }
        cell?.populate()

        return cell ?? CustomCell()
        
    }
    
    // This is the protocol function that is used to receiveData from the APIManager class
    func receiveData(movieList: MovieList) {
        self.movieList = movieList
        
        DispatchQueue.main.async {
            self.movieListTbl.reloadData()
        }
    }
    
    //function called while text in searchBar is changing
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        isSearching = true
        
        //why couldn't i directly set filteredMovies.results from here?
        let temp = movieList?.results?.filter({
            $0.title?.range(of: searchText, options: .caseInsensitive) != nil
        })
        filteredMovies?.results = temp
        
        //this will allow repopulation after user is still editing but has nothing
        //in searchText
        if searchText == "" {
            isSearching = false
        }
        
        movieListTbl.reloadData()
    }
    
    //function called after cancel button is clicked on the searchBar
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        isSearching = false
        searchBar.text = ""
        
        movieListTbl.reloadData()
    }
}
