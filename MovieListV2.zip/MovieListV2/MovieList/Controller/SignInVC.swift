//
//  SignInVC.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/27/21.
//

import UIKit

class SignInVC: UIViewController {

    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var error: UILabel!
    @IBOutlet weak var signIn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // This function will check to make sure the username and password textFields don't exceed 6 characters. If it does exceed the character limit then the error label will become visible
    func validate() -> Bool {
        if(username.text?.count ?? 0 > 6 || password.text?.count ?? 0 > 6){
            error.isHidden = false
            return false
        }
        return true
            
    }

    // This is the SignIn btnClicked function that launches a MovieList View Controller
    @IBAction func btnClicked(_ sender: Any) {
        if(validate()) {
            let st = UIStoryboard(name: "Main", bundle: nil)
            let movieVC = st.instantiateViewController(identifier: "MovieListVC")
            self.navigationController?.pushViewController(movieVC, animated: true)
        }
    }
}
