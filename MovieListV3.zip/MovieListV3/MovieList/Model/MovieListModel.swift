//
//  This creates
//
//  Created by Ethan Rockel on 9/29/21.
//

//This struct is the blueprint for Movies that will be created via api call
//-------------What is codable exactly?
struct Movie : Codable {
    var backdrop_path : String?
    var id : Int?
    var original_title : String?
    var popularity :Double?
    var release_date : String?
    var title:String?
}

//MovieList is an Array of Movies
struct MovieList : Codable {
    var results : [Movie]?
}

