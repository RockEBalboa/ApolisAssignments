import UIKit

class ApiManager {
    
    static let shared = ApiManager()
    
    //delegate is used in MovieListVC to pass data
    var delegate: APIManagerDelegate?
    
    //This function takes a url and converts it into a MovieList
    func getMovieListFromServer(url: String) {
        
        let objUrlSession = URLSession.shared
        
        objUrlSession.dataTask(with: URL.init(string: url)!) { data, response, error in
            
                       guard let data = data else {return}
            
                       // Jsondecoder convert data into model object directly using decode method
                       let jsondecoder = JSONDecoder()
                       let movieList = try! jsondecoder.decode(MovieList.self, from: data)
                       self.delegate?.receiveData(movieList: movieList)
            }.resume()
    }
}

protocol APIManagerDelegate {
    func receiveData(movieList: MovieList)
}
