//
//  APIImageFinder.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/28/21.
//
import UIKit
class APIImageFinder {
    
}
extension  UIImageView {
    //This function grabs an image based on the URL in the parameters
    func imageFromServerURL(_ URLString: String) {
        
        let imagae_url = Constant.IMAGE_BASE_URL.rawValue + URLString
        
        let url = URL(string: imagae_url)

        DispatchQueue.global().async {
            let data = try? Data(contentsOf: url!) //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            DispatchQueue.main.async {
                self.image = UIImage(data: data!)
            }
        }
    }
}
