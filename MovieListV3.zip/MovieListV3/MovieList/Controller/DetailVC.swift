//
//  DetailVC.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/30/21.
//

import UIKit

class DetailVC: UIViewController {
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var popularityLbl: UILabel!
    @IBOutlet weak var releaseDateLbl: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    var movie : Movie?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //this will populate all of the labels and the image view
        titleLbl.text = movie?.title
        popularityLbl.text = "Popularity: \(movie?.popularity ?? -1)"
        releaseDateLbl.text = "Release Date: \(movie?.release_date ?? "")"

        let imgUrl = (Constant.IMAGE_BASE_URL.rawValue + (movie?.backdrop_path ?? ""))
        imgView?.imageFromServerURL(imgUrl)
    }
}
