//
//  ViewController.swift
//  MovieList
//
//  Created by Ethan Rockel on 9/24/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

